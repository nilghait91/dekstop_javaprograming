c = [45,"Harry", False, 6,9]
print(c)