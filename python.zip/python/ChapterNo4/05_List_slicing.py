a =[1,2,3,4,5,6]
print(a)
#we can using item of deffarant types
c = [45,"Harry", False, 6,9]
print(c)
# list slicing
friends = ["Harry","Tom","Rohan","Sam","Divya",45]
print(friends[0:4])
