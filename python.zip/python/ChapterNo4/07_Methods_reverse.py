l1 = [1,8,9,21,15]
l1.reverse()
print (l1)