l1 =[1,4,6,7,8,3]
l1.pop(4)
print(l1)