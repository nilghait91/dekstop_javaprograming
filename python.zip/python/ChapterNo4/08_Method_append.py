l1 =[1,2,4,6,8,9]
l1.append(45)
print(l1)