
f1 = input("Enter fruit Number 1:")
f2 = input("Enter fruit Number 2:")
f3 = input("Enter fruit number 3:")
f4 = input("Enter fruit Number 4:")
f5 = input("Enter fruit Number 5:")
f6 = input("Enter fruit Number 6:")
f7 = input("Enter fruit number 7:")
myfruit = [f1,f2,f3,f4,f5,f6,f7]
print (myfruit)

