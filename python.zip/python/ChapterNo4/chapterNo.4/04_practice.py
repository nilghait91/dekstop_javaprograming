a = [2,3,5,6,7]
print(a[0]+a[1]+a[2]+a[3])
print(sum(a))