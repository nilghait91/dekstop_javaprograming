l1=[1,2,4,5,6,7,8,9]
l1.remove(6)
print(l1)
