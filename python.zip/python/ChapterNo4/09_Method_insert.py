l1 =[1,2,4,6,8,9]
l1.insert(1,544)
print(l1)