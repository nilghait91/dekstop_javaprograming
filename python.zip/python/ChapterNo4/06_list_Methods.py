l1 = [1,8,7,21,15]
l1_sorted = l1.sort()
print(l1_sorted)
