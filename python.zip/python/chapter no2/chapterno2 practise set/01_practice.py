a=34
b=5
print("The sume of a and b is",a+b)