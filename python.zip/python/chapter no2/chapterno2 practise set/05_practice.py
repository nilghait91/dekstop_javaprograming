from audioop import avg


a = input ("Enter first number:")
b = input("Enter secound number:")
a=int(a)
b=int(b)
avg = (a+b)/2
print("The average of a and b is",avg)