a=45
b=15
print("the remider when a is divided by b is",a/b)