a ='''harry'''
b = 345
c = 45.32
d = True
# printing the variable
print(a)
print(b)
print(c)
print(d)
# printing the type of variable
print(type(a))
print(type(b))
print(type(c))
print(type(d))



