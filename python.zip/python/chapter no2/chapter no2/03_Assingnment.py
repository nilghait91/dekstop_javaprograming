a=34
a+=12
print=(a)