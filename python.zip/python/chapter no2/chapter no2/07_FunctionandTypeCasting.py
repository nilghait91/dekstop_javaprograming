
#integer
a= "345"
a=int(a)
print(type(a))
print(a+5)
#string
b= "345"
b= str(b)
print= (type(b))