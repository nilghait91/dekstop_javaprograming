a= "harry"
b="345"
c=45.32
print(a)
print(b)
print(c)