bool1=True 
bool2=False
print("The value of bool1 and bool2 is",(bool1 and bool2))
print("The value of bool1 or bool2 is",(bool1 or bool2))
print("The value of bool1 not bool2 is",(not bool2))