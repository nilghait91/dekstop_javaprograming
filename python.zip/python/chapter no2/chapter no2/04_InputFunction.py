a=input ("Enter your Name:")
#a=int(a)# convert a to an integer (if possible)
print=(a)
