a=3
b=4
print("The value of 3+4",3+4)
print("The value of 3-4",3-4)
print("The value of 3*4",3*4)
print("The value of 3/4",3/4)