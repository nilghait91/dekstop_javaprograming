b=(14<=7)
print(b)