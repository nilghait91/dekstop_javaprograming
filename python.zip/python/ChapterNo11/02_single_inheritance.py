class Employee:
    comapny = "Google"
    def showDetails(self):
        print("This is an employee")
class programmer(Employee):
    language = "Python" 
    #company = "YouTube"

    def getLanguage(self):
        print(f"The language is{self.language}")
    def showDetails(self):
        print("This is a programmer")
e = Employee()
e.showDetails()
p = programmer()
p.showDetails()
print(p.company)           