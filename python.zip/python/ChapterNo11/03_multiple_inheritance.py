class Freelancer:
    comapny ="fiverr"
    level = 0
def ungradeLevel(self):
        self.Level = self.level + 1
class Employee:
    company ="Visa"
    eCode = 120
class programmer(Freelancer, Employee):
    name ="Rohit"
p = programmer()
p.upgradeLevel()
print(p.company)