class Animals:
    animalsType = "Mammal"
class pets:
    color = "White"
class Dog:
    @staticmethod
    def bark():
        print("Bow bow!")
d = Dog()
d.bark()