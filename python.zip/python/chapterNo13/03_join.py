l = ["Camera","Phone","ipad","Hard Disk","Nvidia Graphic3080 card"]
sentence = " ~~".join(l)
sentence = "==".join(l)
sentence = "\n".join(l)
print(sentence)
print(type(sentence))