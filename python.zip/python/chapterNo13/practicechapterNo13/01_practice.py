
name = input("Enter your name:")
marks =input("Enter your marks:")
phone = input("Enter your phone Number:")

template = "The name of the student is {}, his marks ar {} and phone numver is {}"
output = template.formate(name,marks,phone)
print(output)