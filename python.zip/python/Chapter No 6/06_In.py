a = [45,56,6]
print(435 in a)
