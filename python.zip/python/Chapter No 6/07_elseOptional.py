if(3==10):
    print("Yes")
elif(3>=56):
    print("No and Yes")
else:
    print("I am Optional")

