age = int(input("Enter your age :"))
if(age>34 or age <56):
    print("your can work with us")