# if-elif-else ladder in python
a = 15
if (a>15):
    print("The value of a is greater than 3")
if(a>13):
    print("The value of a is greater than 13")
if(a>7):
    print("The value of is greater than 7")
if(a<17):
    print("The value of greater than 17")
else:
    print("The value of is not greater than 3 or 17")
    print("Done")

