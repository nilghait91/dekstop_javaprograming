Sub1 = int(input("Enter subject marks \n"))
Sub2 = int(input("Enter secound subject marks \n"))
Sub3 = int(input("Enter third subject marks \n"))
if(Sub1 < 33 or Sub2 < 33 or Sub3 < 33): 
    print("You are fail because your have less than 33%  in one of the subjects")
elif(Sub1+ Sub2 + Sub3)/3 < 40:
    print("You are fail due to total percentage less than 40")
else:
    print("Congatulation! You passed exam")