if "marks">=90:
    grade="Ex"
elif "marks">80:
    grade ="a"
elif "mark">=70:
    grade="b"
elif "marks">=60:
    grade ="c"
elif "mark">=50: 
 grade="d"
  
else:
    grade ="f"
print("Your grade is"+grade)
     