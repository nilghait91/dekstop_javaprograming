Name = ["Harry","Shubham","Rohit","jagan","shri"]
Name = input ("Enter Name to check \n")
if Name in Name:
    print("Your Name is present in the list")
else:
    print("Your Name is not present in the list")