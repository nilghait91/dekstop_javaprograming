num1=int(input("Enter number1:"))
num2=int(input("Enter number2:"))
num3=int(input("Enter number3:"))
num4=int(input("Enter number4:"))

if(num1>num4):
    F=num1 
else:

    F1= num4

if(num2>num3):

   F2 = num2

else:

    F2 = num3
if(F1>F2):
  print (str(F1) + "is greatest")
else:
    print(str(F2)+"is greatest")
