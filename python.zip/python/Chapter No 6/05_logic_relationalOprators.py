
#In or is 
a = None
if(a is None):
  print("Yes")
else:
    print("No")
