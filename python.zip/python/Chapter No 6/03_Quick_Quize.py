# write a program to print yes when the age enterd by the user is greater than or equal to 18?
 
age = int(input("Enter your age:"))
if age>18:
   print("Yes")
else:
  print("No")

    