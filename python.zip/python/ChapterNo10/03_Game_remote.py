class Remote():
    pass
class player:
    def moveRight(self):
        pass
    def moveleft(self):
        pass
    def moveTop(self):
        pass
remote1 = Remote()
player1 = player()

if(remote1.isLeftPressed()):
        player1.moveLeft()