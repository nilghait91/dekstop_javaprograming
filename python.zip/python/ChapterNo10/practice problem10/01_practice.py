class Programmer:
    company = "microsoft"
    def __init__(self, name, product):
        self.name = name 
        self.product = product
    def getInfo(self):
        print(f"The name of the {self.company} Programmer is {self.name}\n and the product is {self.product}")
harry = Programmer("Harry", "skype")
Alka  = Programmer("Alka", "GitHub")
harry.getInfo()
Alka.getInfo()