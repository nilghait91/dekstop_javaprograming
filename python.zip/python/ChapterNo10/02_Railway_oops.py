class RailwayForm :
    formType ="RailwayFrom"
    def printData(self):
       print(f"Name is {self.name}")
       print(f"Train is {self.train}")
harryApplication = RailwayForm()
harryApplication.name ="Harry"
harryApplication.train = "Rajdhani experess"
harryApplication.printData()