

import os
print(os.listdr())