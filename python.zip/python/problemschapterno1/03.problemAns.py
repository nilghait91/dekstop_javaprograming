from playsound import playsound
playsound('C:\\Users\\HP Notebook\\Desktop\\python\\play.mp3.mp3')
