# author:Harry 
# location:mark 
# date:23/10/2022 

import os 
print(listdir())