
try:
    a=int(input("Enter a number:"))
    c =1/a 
except ValueError as e:
        print("please Enter a valid value")
except ZeroDivisionError as e:
    print("Thanks for using this code!")
