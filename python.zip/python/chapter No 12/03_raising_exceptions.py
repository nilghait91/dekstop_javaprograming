def increament(num):
    try:
        return int(num)+1
    except:
        raise ValueError("This is not good -Harry")
a = increament("df364")
print(a)