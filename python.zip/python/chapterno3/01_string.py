# b ="harry's" 
# b ='harry"s'
b ='''harry's'''
print(b)
print(type(b))