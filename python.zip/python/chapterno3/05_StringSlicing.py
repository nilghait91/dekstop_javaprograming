from unicodedata import name


name = "Harry"
print(name[0:3])
print(name[:4])