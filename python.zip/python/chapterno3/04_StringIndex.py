Name = "Harry"
print = (Name(2))
print =(type(Name))