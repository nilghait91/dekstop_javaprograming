from unicodedata import name


name = "Harry"
c = name[-4 : -1]
print(c)