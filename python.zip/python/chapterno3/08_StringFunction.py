Story =" one upon a time there was a youtubeer named harry who upload python course with notes."
#print(len(Story))
# print(Story.endswith("notes"))
# print(Story.count("a"))
# print(Story.capitalize( ))
# print(Story.find("Harry"))

