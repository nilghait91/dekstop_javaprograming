greeting = "Good morninng"
name = "harry"
print (type(name))