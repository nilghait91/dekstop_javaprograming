Story = "Harry is good\n he\t is ve\\ry good"
print(Story)