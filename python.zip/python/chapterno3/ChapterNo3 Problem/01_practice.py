name = input("Enter your name \n")
print("Good afternoon," + name)