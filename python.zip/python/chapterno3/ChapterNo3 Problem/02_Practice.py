letter = '''Dear <|NAME|>
           your selected 
             Date:<|DATE|>'''
name =("Enter your name\n")
Date =("Enter Date\n")
letter = letter.replace("<|name|>",name)
letter = letter.replace("<|Date|>",Date)

print(letter)
