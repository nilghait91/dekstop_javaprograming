letter = "Dear Harry,This python course is nice Thanks !"
print (letter)
formated_letter ="Dear Harry,\n \t this is python course is nice!\nThanks!"
print(formated_letter)