st = "This is a string with double   spaces     idhl"
doubleSpaces = st.replace(" " ," ")
print(st)