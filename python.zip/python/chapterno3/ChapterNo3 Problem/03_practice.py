st = "This is a string with double spaces"
doublespaces= st.find(" ")
print (doublespaces)