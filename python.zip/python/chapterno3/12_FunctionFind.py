Story =" one upon a time there was a youtubeer named harry who upload python course with notes."
print(Story.find("harry"))
