name = " Harry is good"
d = name [1:4:1]
print(d)