greeting = "Good morning "
name = "harry"
c = greeting + name 
print (c)


