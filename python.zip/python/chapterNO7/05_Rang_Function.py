for i in range (8):
    print(i)
else:
    print("This is inside else of for")