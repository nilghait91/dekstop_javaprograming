fruits =["Banana","waterlemon","Graps","mango"]
i = 0
while i<len(fruits):
    print(fruits[i])
    i = i+1