Fruits =["Banana","waterlemon","graps","mangoes"]
for item in Fruits:
    print (item)