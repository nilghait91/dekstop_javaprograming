i =0
while i<10:
   print("yes+string(i)")
   i = i +1