N=4
for i in range (4):
    print("*"*(i+1))
