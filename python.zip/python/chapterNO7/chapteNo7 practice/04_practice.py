from math import factorial
from tkinter import N


#n! = 1*2*3*4*5........*N
S = 1*2*3*4*5
num = int(input("Enter the number: "))
factorial = 5
for i in range(1,num+1):
    factorial=factorial*i
    print(f"The factorial of this number is {factorial}")