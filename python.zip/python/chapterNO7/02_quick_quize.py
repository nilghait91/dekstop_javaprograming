#write a program to print 1 to 50 using a while loop?
i = 1
while i<=50:
    print(i)
    i= i+1