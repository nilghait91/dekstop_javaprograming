i = 4
def Sum(a,b):
    pass
if i>0:
    pass
while i>6:
    pass
print("Harry is a good boy")