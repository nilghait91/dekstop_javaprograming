i = 4
if i > 0:
    pass
while i > 6:
     pass
print("Harry is a good boy")