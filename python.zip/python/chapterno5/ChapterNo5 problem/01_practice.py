myDict = {
    "pankha":"Fan",
    "Dabba":"Box",
    "Vastu":"Item"
    }
print("Options are",myDict.keys())
a = input("Enter the Hindi Word\n")
#print("The meaning of your word is:",myDict[a])
print("The Meaning of your word is:",myDict.get(a))