FavLang = { }
a = input("Enter your favorite language Subham\n")
b = input("Enter your favorite language Ganesh\n")
c = input("Enter your favorite language Gajanan\n")
d = input("Enter your favorite language Mayur\n")
FavLang["Shubham"]=a
FavLang["Ganesh"]=b
FavLang["Gajanan"]=c
FavLang["Mayur"]=d
print(False)