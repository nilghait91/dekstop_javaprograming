a =set()
a.add(4)
a.add(5)
a.add(4)
a.add(6)
a.add((4,5,6)) #add in set 
print(a)