a = {1,3,4,5,1,6}
print(type(a))
print(a)