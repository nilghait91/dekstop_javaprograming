MyDict = {
    "Fast" : "In a Quick Manner",
    "Harry" : "A Coder",
    "Marks" : [1,2,5],
    "AnotherDict" : {'harry':'player'},
    1:2
}
print(MyDict.values())