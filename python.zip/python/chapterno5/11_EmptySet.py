a = set()
print(type(a))