a = {}
print (type(a))