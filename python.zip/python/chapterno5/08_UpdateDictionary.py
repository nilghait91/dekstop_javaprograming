MyDict = {
    "Fast" : "In a Quick Manner",
    "Harry" : "A Coder",
    "Marks" : [1,2,5],
    "AnotherDict" : {'harry':'player'},
    1:2
}
print(MyDict.keys())
print(MyDict.values())
print(MyDict.items())
print(MyDict)
updateDict = {
    "Lovish" : "Friend",
    "Divya" :"Friend",
    "Shubham" : "Friend",
    "Harry" : "A Dancer" 
}
MyDict.update(updateDict)
print(MyDict)
