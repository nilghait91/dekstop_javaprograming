f = open ("sample2.txt")
#read first line 
data = f.readline()
print (data)
#read secound line
data = f.readline()
print (data)
#read third line 
data = f.readline()
print(data)
f.close()