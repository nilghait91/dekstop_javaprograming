with open("with.txt","r")as f:
    a=f.read()
with open("with.txt","w")as f:
    a = f.write("me \n")
    a = f.write("harry")
print(a)