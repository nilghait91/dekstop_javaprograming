content = True
i = 2
with open("logcha7.txt")as f:
    while content:
        content = f.readline()
        if 'python' in content.lower():
            print()
            print(f"Yes python is present on line number {i}")
        i+=1
