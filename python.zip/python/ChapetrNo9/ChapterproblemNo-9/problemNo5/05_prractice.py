word = ["donkey","kaddu","mote"]

with open("repeat.txt") as f:
    content = f.read()


for word in word:
    content = content.replace(word,"$%^@$^#")
    with open("repeat.txt" , "w") as f:
        f.write(content)
