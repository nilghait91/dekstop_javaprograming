import os


oldname = "sample.txt"
Newname = "renamed_by_python.txt"
with open(oldname)as f:
    content = f.read()
with open(Newname,"w")as f:
    f.write(content)
os.remove(oldname)