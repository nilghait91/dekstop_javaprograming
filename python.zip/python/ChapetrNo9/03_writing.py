f = open('another.txt','w')
f.write("i am writing \n")
f.write("please write this to the file")
f.close()