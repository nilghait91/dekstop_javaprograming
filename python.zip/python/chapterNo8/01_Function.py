def percentage(marks):
    p=((marks[0] + marks[2] + marks[3])/400)*100
    return p
marks1 = [45,78,88,77]
percentage1 = percentage(marks1)
marks2 = [75,87,67,90]
percentage2 = percentage(marks2)
print(percentage1,percentage2)