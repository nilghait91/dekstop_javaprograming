def forh(cel):
    return(c*(9/5)+32)
c=0
f=forh(c)
print("farhreit temperature is" + str(f))
