n = 6
for i in range (n):
    print(" * " *(n-i))