This = "  Harry is a good "
print(This)
print(This.strip())