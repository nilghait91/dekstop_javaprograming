def fun1( ):
    print("Hello")

#function call

function1=()
print("hello")