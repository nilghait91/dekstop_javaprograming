# Write a program to greate a user with "good day" using function?
def greet(Name):
    print("Good Day," + Name) 
greet ("Harry")