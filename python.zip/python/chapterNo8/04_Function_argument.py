def greet(name):
    print ("Good Day," + name)
def mysum(num1,num2):
    return num1+num2
greet("Harry")
S = mysum(6,33)
print(S) 