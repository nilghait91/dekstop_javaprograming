from tkinter import N


#n! = 1 * 2 * 3 * 4 * 
n=4
product = 1
for i in range(n):
 product = product*(i+1)
print(product)
