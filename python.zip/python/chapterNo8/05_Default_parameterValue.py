def greet(name="stranger"):
  print("Good Day," + name)
greet("Harry")
greet()
