let digit1=12;
let x =4;
let z = digit1+x;
console.log(z);