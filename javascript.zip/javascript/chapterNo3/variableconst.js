let digit1 = 10;
const x =2;
digit1 = 20;
console.log(digit1)

let digit3 = 10;
const y = 5;
digit3 = 20;
x = 5;
console.log(x)