var digit1 = 5;
alert(digit1)
console.log("digit1")