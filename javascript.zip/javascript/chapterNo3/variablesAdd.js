var digit1=15;
var x = 2;
var z = digit1+x;
alert(z);
console.log(z);