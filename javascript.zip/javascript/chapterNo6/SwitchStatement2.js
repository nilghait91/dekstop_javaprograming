switch(input = "N"){
    case 1: // if (input === 1)
    case  "y": // if (input === "y")
    case "yes": // if (input === "yes")
    document.write ("continue...");
    break;
    case 0 : // if (input ===0)
    case "N": // if (input === "N")
    case "No":// if (input === "NO")
    document.write ("End....");
    break;
    default:
        document.write("wrong input");
}