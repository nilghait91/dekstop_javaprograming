let man=["name","tom","age:60"];
console.log(man);


/*undifine [datype]*/
let x;
console.log(x);

let y = typeof 10;
console.log(x);