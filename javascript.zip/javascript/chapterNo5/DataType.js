let x = ("hello")
let y = ('hello')
console.log(x);