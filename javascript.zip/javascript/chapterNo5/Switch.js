//if input = 1 "y" , "yes" output = continue
// if input = 0 "n" ,"no" output = End
let input
input = "N";
if (input === 1){
    document.write("continue....")
} else if (input ==="y"){
    document.write("continue....")
} else if(input ==="yes"){
     document.write("continue.....")
} else if(input === "0"){
    document.write("End....")
} else if(input === "N"){
    document.write("End....")
} else if(input === No){
    document.write("End.....")
}else{
    document.write("wrong input");
}
