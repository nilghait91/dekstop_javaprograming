//if 0 logeedout if 1 login/
let  islogeedin = 0;
let islogout=1;
if(islogeedin == 1)
{
    document.write("login");
} else{
    document.write("logout");
}