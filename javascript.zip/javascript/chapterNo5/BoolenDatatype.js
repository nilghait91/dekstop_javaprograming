let x = 3<5;
let y = 10<5;
console.log(x);
alert(y);