let x = typeof 10;
console.log(x);