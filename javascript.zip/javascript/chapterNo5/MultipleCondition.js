let age = 15;
let hasvotercard = 'yes';
if(age>=14 && hasvotercard){
    alert('you can vote');
} else(age<=14 && hasvotercard)
{
  alert('you cannot vote');
} 
alert("get your voter id card")
{
    alert('you can  vote')
}

