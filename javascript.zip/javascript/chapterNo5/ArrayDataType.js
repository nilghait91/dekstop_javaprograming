let x = ["vishwajeet","tom","jhon"];
console.log(x)