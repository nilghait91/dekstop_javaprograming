//xxx comparasation switch(input=1)

switch(input = 1){
    case 1: // if (input ===1);
    document.write("continue...");
    break;
}
switch(input = "y"){
    case "y": // if (input ==="y");
    document.write("continue...");
    break;
}
switch(input="yes"){
    case "yes": // if(input ==="yes")
    document.write("continue...");
    break;
}
switch(input="0"){
        case "0":// if (input === "0")
        document.write("End...");
        break;
}
switch(input="N"){
    case "N": // if (input ==="N")
    document.write("End...")
    break;
}
switch(input = "No"){
    case "No":// if (input ==="No")
    document.write("End...")
    break;
    default:
} 
    document.write ("wrong input")
 