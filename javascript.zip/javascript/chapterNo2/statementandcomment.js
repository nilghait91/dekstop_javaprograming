var a;
a=5;
alert(a);

/*var b;
b=7;
alert(b);*/ 