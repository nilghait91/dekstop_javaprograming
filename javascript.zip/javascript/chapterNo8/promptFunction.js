let age = prompt("Enter your age");
if (age = 25){
    document.write('your age is {25}');
} else{
    document.write('your age is blank');
}