confirm('Are you confirm sure,you want to delet ?')
let response 
if(response)
{
    document.write('deleted');
} else{
    document.write('Not deleted');
}
