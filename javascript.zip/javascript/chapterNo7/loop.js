let counter = 1;
while(counter<=10){
    document.write("techgun\n");
    counter++;
}