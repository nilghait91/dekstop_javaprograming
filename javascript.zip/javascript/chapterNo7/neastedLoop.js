for(let counter = 1; counter<=10;counter++){
    document.write("counter\n");
    document.write('<br>');

for(let counter2 = 1; counter2 <3 ; counter2++){
    document.write("techGun\n");
    document.write("techGun\n");
}
};