for(let counter =1; counter<=10;counter++)
{
    if(counter == 5){
        continue;
    }
    document.write(counter);
    document.write('<br>');
}