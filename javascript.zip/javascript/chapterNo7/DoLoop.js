let counter = 12;
do{
    document.write("techGun")
    counter++
} while(counter<=10);