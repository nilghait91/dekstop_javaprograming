for(let counter= 1; counter<=10; counter++ )
{
    document.write("techGun \n");
}