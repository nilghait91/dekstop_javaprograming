let x;
x = 18;
let y;
y=10;
x=y;
let z;
z = x+y;

console.log(z);