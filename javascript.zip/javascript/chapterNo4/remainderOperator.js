let x;
x = 10;
let y = 3;
let z;
z= x%3;
console.log(z);