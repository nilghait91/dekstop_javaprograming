let x = ("hello")
let y = ("world")
console.log(x+ " "+y); /* use this function space */


/*  use the ++ and -- */
let p = 5;
p --;
console.log(p);

/* use the / */
 let a = 5;
 let b = (a+5)/5;
 console.log(b);