let x = 5;
let y ='5';
console.log(x+y);