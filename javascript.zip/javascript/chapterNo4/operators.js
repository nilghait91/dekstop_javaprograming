let x ;
x = 5;
let y;
y = 10;
x=y;
console.log(x);