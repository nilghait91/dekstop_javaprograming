let x;
x = 3;
let y = 5;
let z;
z= y **3;
console.log(z);