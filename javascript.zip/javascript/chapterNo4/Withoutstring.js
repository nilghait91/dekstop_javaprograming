let x = 5;
let y = 10;
console.log(x+y);